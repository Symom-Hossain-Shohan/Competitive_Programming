firsName="ada"
lastName="lovelace"

fullName=f"{firsName} {lastName}"

print(fullName)
