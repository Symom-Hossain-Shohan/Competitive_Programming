messsage="hello python world"
print (m