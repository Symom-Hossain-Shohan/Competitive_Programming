printf("SOLN       COLUMN\n");
        printf(" #      1 2 3 4 5 6 7 8\n\n");
        NQueens(1);
        if(TC) printf("\n");